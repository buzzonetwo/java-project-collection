WASD to move the pointer
QE to spin 
Hold H to erase
R to reset

Pointer thickness and color and background color can be changed with the buttons at the bottom

Note: the button outlines will also spin, but where they are supposed to be can still be clicked
Help screen shows on startup and can be accessed again by clicking the bottom left question mark
